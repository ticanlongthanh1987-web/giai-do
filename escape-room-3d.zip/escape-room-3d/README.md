# Escape Room 3D (Godot 4)

Game giải đố thoát phòng góc nhìn thứ nhất. Mục tiêu: tìm manh mối, mở két sắt, lấy chìa khóa, mở cửa thoát ra.

## Cách chạy
1. Tải Godot 4.2 trở lên tại https://godotengine.org (bản Standard, không cần cài đặt).
2. Mở Godot -> Import -> chọn file `project.godot` trong thư mục này.
3. Bấm F5 để chơi.

## Điều khiển
- WASD hoặc phím mũi tên: di chuyển
- Chuột: nhìn xung quanh
- E: tương tác (đọc, kéo thảm, mở két, mở cửa)
- Esc: đóng bàn phím nhập mã

## Cấu trúc
- `main.gd`: dựng căn phòng, đồ vật, giao diện và logic câu đố
- `player.gd`: di chuyển, camera, tia nhìn để tương tác
- `main.tscn`: scene chính (chỉ có một node gắn `main.gd`)

## Đưa lên GitHub
Thư mục đã có sẵn `.gitignore` cho Godot. Chỉ cần tạo repo rồi upload toàn bộ thư mục này.
